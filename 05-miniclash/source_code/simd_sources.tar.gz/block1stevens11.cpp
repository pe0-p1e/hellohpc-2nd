#include <iostream>
#include <vector>
#if defined(__x86_64__) || defined(__i386__)
#include <immintrin.h>
#endif
#include "main.hpp"


static inline __attribute__((always_inline)) bool finish_stevens_candidate(
    uint32 block[], const uint32 IV[], uint32 a, uint32 b, uint32 c, uint32 d)
{
    MD5_STEP(II, a, b, c, d, block[12], 0x655b59c3, 6);
    if (0 != ((a^c) >> 31)) return false;
    MD5_STEP(II, d, a, b, c, block[3], 0x8f0ccc92, 10);
    if (0 != ((b^d) >> 31)) return false;
    MD5_STEP(II, c, d, a, b, block[10], 0xffeff47d, 15);
    if (0 != ((a^c) >> 31)) return false;
    MD5_STEP(II, b, c, d, a, block[1], 0x85845dd1, 21);
    if (0 != ((b^d) >> 31)) return false;
    MD5_STEP(II, a, b, c, d, block[8], 0x6fa87e4f, 6);
    if (0 != ((a^c) >> 31)) return false;
    MD5_STEP(II, d, a, b, c, block[15], 0xfe2ce6e0, 10);
    if (0 != ((b^d) >> 31)) return false;
    MD5_STEP(II, c, d, a, b, block[6], 0xa3014314, 15);
    if (0 != ((a^c) >> 31)) return false;
    MD5_STEP(II, b, c, d, a, block[13], 0x4e0811a1, 21);
    if (0 == ((b^d) >> 31)) return false;
    MD5_STEP(II, a, b, c, d, block[4], 0xf7537e82, 6);
    if (0 != ((a^c) >> 31)) return false;
    MD5_STEP(II, d, a, b, c, block[11], 0xbd3af235, 10);
    if (0 != ((b^d) >> 31)) return false;
    MD5_STEP(II, c, d, a, b, block[2], 0x2ad7d2bb, 15);
    if (0 != ((a^c) >> 31)) return false;
    MD5_STEP(II, b, c, d, a, block[9], 0xeb86d391, 21);

    uint32 block2[16];
    uint32 V1[4], V2[4];
    for (int t = 0; t < 4; ++t) {
        V1[t] = IV[t];
        V2[t] = IV[t] + (1u << 31);
    }
    V2[1] -= (1u << 25);
    V2[2] -= (1u << 25);
    V2[3] -= (1u << 25);
    for (int t = 0; t < 16; ++t) block2[t] = block[t];
    block2[4] += 1u << 31;
    block2[11] += 1u << 15;
    block2[14] += 1u << 31;
    md5_compress(V1, block);
    md5_compress(V2, block2);
    return V2[0]==V1[0] && V2[1]==V1[1] && V2[2]==V1[2] && V2[3]==V1[3];
}

void find_block1_stevens_11(uint32 block[], const uint32 IV[])
{
	uint32 Q[68] = { IV[0], IV[3], IV[2], IV[1] };

	std::vector<uint32> q9q10mask(1<<5);
	for (unsigned k = 0; k < q9q10mask.size(); ++k)
		q9q10mask[k] = ((k<<5) ^ (k<<6) ^ (k<<7) ^ (k<<24) ^ (k<<27)) & 0x880002a0;
	
	std::vector<uint32> q9mask(1<<9);
	for (unsigned k = 0; k < q9mask.size(); ++k)
		q9mask[k] = ((k<<1) ^ (k<<3) ^ (k<<8) ^ (k<<12) ^ (k<<15) ^ (k<<18)) & 0x04710c12;
	
	while (true) 
	{
		uint32 aa = Q[Qoff] & 0x80000000;

		Q[Qoff + 2] = (xrng64() & 0x75bef63e) | 0x0a410041 | aa;
		Q[Qoff + 3] = (xrng64() & 0x10345614) | 0x0202a9e1 | (Q[Qoff + 2] & 0x84000002);
		Q[Qoff + 4] = (xrng64() & 0x00145400) | 0xe84ba909 | (Q[Qoff + 3] & 0x00000014);
		Q[Qoff + 5] = (xrng64() & 0x80000000) | 0x75e90b1d | (Q[Qoff + 4] & 0x00145400);
		Q[Qoff + 6] = 0x7c23ff5a | (Q[Qoff + 5] & 0x80000000);
		Q[Qoff + 7] = (xrng64() & 0x40000880) | 0x114bf41a;
		Q[Qoff + 8] = (xrng64() & 0x00002090) | 0xb352dd01;
		Q[Qoff + 9] = (xrng64() & 0x00044000) | 0x7a803124;
		Q[Qoff +10] = (xrng64() & 0x00002000) | 0xf28a92c9 | (Q[Qoff + 9] & 0x00044000);
		Q[Qoff +11] = (xrng64() & 0x128a8108) | 0xc5710ed7 | (Q[Qoff + 10] & 0x00002000);
		Q[Qoff +12] = (xrng64() & 0x9edb8d7f) | 0x20003080 | (~Q[Qoff + 11] & 0x00200000);
		Q[Qoff +13] = (xrng64() & 0x3efb1d77) | 0x4004c008 | (Q[Qoff + 12] & 0x80000000);
		Q[Qoff +14] = (xrng64() & 0x1fff5d77) | 0x0000a288;
		Q[Qoff +15] = (xrng64() & 0x1efe7ff7) | 0x20008000 | (~Q[Qoff + 14] & 0x00010000);
		Q[Qoff +16] = (xrng64() & 0x1ffdffff) | 0x20000000 | (~Q[Qoff + 15] & 0x40020000);
		
		MD5_REVERSE_STEP(5, 0x4787c62a, 12);
		MD5_REVERSE_STEP(6, 0xa8304613, 17);
		MD5_REVERSE_STEP(7, 0xfd469501, 22);
		MD5_REVERSE_STEP(11, 0x895cd7be, 22);
		MD5_REVERSE_STEP(14, 0xa679438e, 17);
		MD5_REVERSE_STEP(15, 0x49b40821, 22);

		const uint32 tt17 = GG(Q[Qoff + 16], Q[Qoff + 15], Q[Qoff + 14]) + Q[Qoff + 13] + 0xf61e2562;
		const uint32 tt18 = Q[Qoff + 14] + 0xc040b340 + block[6];
		const uint32 tt19 = Q[Qoff + 15] + 0x265e5a51 + block[11];

		const uint32 tt0 = FF(Q[Qoff + 0], Q[Qoff - 1], Q[Qoff - 2]) + Q[Qoff - 3] + 0xd76aa478;
		const uint32 tt1 = Q[Qoff - 2] + 0xe8c7b756;		

		const uint32 q1a = 0x02000861 ^ (Q[Qoff + 0] & 0x80000020);
		
		unsigned counter = 0;
		while (counter < (1 << 12))
		{
			++counter;

			uint32 q1 = q1a | (xrng64() & 0x7dfff79e);
			uint32 m1 = Q[Qoff+2] - q1;
			m1 = RR(m1, 12) - FF(q1, Q[Qoff+0], Q[Qoff-1]) - tt1;

			const uint32 q16 = Q[Qoff+16];
			uint32 q17 = tt17 + m1;
			q17 = RL(q17, 5) + q16;
			if (0x40000000 != ((q17^q16) & 0xc0008008)) continue;
			if (0 != (q17 & 0x00020000)) continue;

			uint32 q18 = GG(q17, q16, Q[Qoff+15]) + tt18;
			q18 = RL(q18, 9); q18 += q17;
			if (0x80020000 != ((q18^q17) & 0xa0020000)) continue;

			uint32 q19 = GG(q18, q17, q16) + tt19;
			q19 = RL(q19, 14); q19 += q18;
			if (0x80000000 != (q19 & 0x80020000)) continue;

			uint32 m0 = q1 - Q[Qoff + 0];
			m0 = RR(m0, 7) - tt0;

			uint32 q20 = GG(q19, q18, q17) + q16 + 0xe9b6c7aa + m0;
			q20 = RL(q20, 20); q20 += q19;
			if (0x00040000 != ((q20^q19) & 0x80040000))	continue;
			
			Q[Qoff + 1] = q1;
			Q[Qoff + 17] = q17;
			Q[Qoff + 18] = q18;
			Q[Qoff + 19] = q19;
			Q[Qoff + 20] = q20;

			block[0] = m0;
			block[1] = m1;

			MD5_REVERSE_STEP(5, 0x4787c62a, 12);
			uint32 q21 = GG(Q[Qoff+20], Q[Qoff+19], Q[Qoff+18]) + Q[Qoff+17] + 0xd62f105d + block[5];
			q21 = RL(q21, 5); q21 += Q[Qoff+20];
			if (0 != ((q21^Q[Qoff+20]) & 0x80020000)) continue;

			Q[Qoff+21] = q21;

			counter = 0;
			break;
		}
		if (counter != 0)
			continue;

		const uint32 q9b = Q[Qoff + 9];
		const uint32 q10b = Q[Qoff + 10];

		MD5_REVERSE_STEP(2, 0x242070db, 17);
		MD5_REVERSE_STEP(3, 0xc1bdceee, 22);
		MD5_REVERSE_STEP(4, 0xf57c0faf, 7);
		MD5_REVERSE_STEP(7, 0xfd469501, 22);

		const uint32 tt10 = Q[Qoff + 7] + 0xffff5bb1;
		const uint32 tt22 = GG(Q[Qoff + 21], Q[Qoff + 20], Q[Qoff + 19]) + Q[Qoff + 18] + 0x02441453;
		const uint32 tt23 = Q[Qoff + 19] + 0xd8a1e681 + block[15];
		const uint32 tt24 = Q[Qoff + 20] + 0xe7d3fbc8 + block[4];
	 
		for (unsigned k10 = 0; k10 < (1<<5); ++k10)
		{
			uint32 q10 = q10b | (q9q10mask[k10]&0x08000040);
			uint32 m10 = RR(Q[Qoff+11]-q10,17);
			uint32 q9 = q9b | (q9q10mask[k10]&0x80000280);

			m10 -= FF(q10, q9, Q[Qoff+8]) + tt10;

			uint32 aa = Q[Qoff + 21];
			uint32 dd = tt22+m10; dd = RL(dd, 9) + aa;
			if (0 == (dd & 0x80000000)) continue;			

			uint32 bb = Q[Qoff + 20];
			uint32 cc = tt23 + GG(dd, aa, bb); 
			if (0 != (cc & 0x20000)) continue;
			cc = RL(cc, 14) + dd;
			if (0 != (cc & 0x80000000)) continue;

			bb = tt24 + GG(cc, dd, aa); bb = RL(bb, 20) + cc;
			if (0 == (bb & 0x80000000)) continue;

			block[10] = m10;
			Q[Qoff + 9] = q9;
			Q[Qoff + 10] = q10;
			MD5_REVERSE_STEP(13, 0xfd987193, 12);


#if defined(__AVX512F__)
            const uint32 tt8v_s = FF(Q[Qoff+8], Q[Qoff+7], Q[Qoff+6]) + Q[Qoff+5] + 0x698098d8u;
            const uint32 tt9v_s = Q[Qoff+6] + 0x8b44f7afu;
            const uint32 tt12v_s = RR(Q[Qoff+13]-Q[Qoff+12],7)
                - FF(Q[Qoff+12],Q[Qoff+11],q10) - 0x6b901122u;
            const __m512i vq9base = _mm512_set1_epi32((int)q9);
            const __m512i vq8 = _mm512_set1_epi32((int)Q[Qoff+8]);
            const __m512i vq7 = _mm512_set1_epi32((int)Q[Qoff+7]);
            const __m512i vq10 = _mm512_set1_epi32((int)q10);
            const __m512i vtt8 = _mm512_set1_epi32((int)tt8v_s);
            const __m512i vtt9 = _mm512_set1_epi32((int)tt9v_s);
            const __m512i vtt12 = _mm512_set1_epi32((int)tt12v_s);
            const __m512i vaa0 = _mm512_set1_epi32((int)aa);
            const __m512i vbb0 = _mm512_set1_epi32((int)bb);
            const __m512i vcc0 = _mm512_set1_epi32((int)cc);
            const __m512i vdd0 = _mm512_set1_epi32((int)dd);
            const __m512i signbit = _mm512_set1_epi32((int)0x80000000u);
            const __m512i bit15 = _mm512_set1_epi32(1 << 15);
            alignas(64) uint32 la[16],lb[16],lc[16],ld[16],l8[16],l9[16],l12[16];

#define SG(x,y,z) _mm512_xor_si512((y), _mm512_and_si512((z), _mm512_xor_si512((x),(y))))
#define SH(x,y,z) _mm512_xor_si512(_mm512_xor_si512((x),(y)),(z))
#define SI(x,y,z) _mm512_xor_si512((y), _mm512_or_si512((x), _mm512_xor_si512((z), _mm512_set1_epi32(-1))))
#define SSTEP_G(A,B,C,D,M,K,R) do { (A)=_mm512_add_epi32((A),_mm512_add_epi32(SG((B),(C),(D)),_mm512_add_epi32((M),_mm512_set1_epi32((int)(K))))); (A)=_mm512_add_epi32(_mm512_rol_epi32((A),(R)),(B)); } while(0)
#define SSTEP_H(A,B,C,D,M,K,R) do { (A)=_mm512_add_epi32((A),_mm512_add_epi32(SH((B),(C),(D)),_mm512_add_epi32((M),_mm512_set1_epi32((int)(K))))); (A)=_mm512_add_epi32(_mm512_rol_epi32((A),(R)),(B)); } while(0)
#define SSTEP_I(A,B,C,D,M,K,R) do { (A)=_mm512_add_epi32((A),_mm512_add_epi32(SI((B),(C),(D)),_mm512_add_epi32((M),_mm512_set1_epi32((int)(K))))); (A)=_mm512_add_epi32(_mm512_rol_epi32((A),(R)),(B)); } while(0)

            for (unsigned k9 = 0; k9 < q9mask.size(); k9 += 16) {
                __m512i q9v = _mm512_xor_si512(vq9base,
                    _mm512_loadu_si512((const void*)(&q9mask[k9])));
                __m512i b12v = _mm512_sub_epi32(vtt12, q9v);
                __m512i b8v = _mm512_sub_epi32(_mm512_ror_epi32(_mm512_sub_epi32(q9v,vq8),7),vtt8);
                __m512i ff9 = _mm512_xor_si512(vq7,_mm512_and_si512(q9v,_mm512_xor_si512(vq8,vq7)));
                __m512i b9v = _mm512_sub_epi32(_mm512_sub_epi32(
                    _mm512_ror_epi32(_mm512_sub_epi32(vq10,q9v),12),ff9),vtt9);
                __m512i a=vaa0,b=vbb0,c=vcc0,d=vdd0;
                SSTEP_G(a,b,c,d,b9v,0x21e1cde6,5);
                SSTEP_G(d,a,b,c,_mm512_set1_epi32((int)block[14]),0xc33707d6,9);
                SSTEP_G(c,d,a,b,_mm512_set1_epi32((int)block[3]),0xf4d50d87,14);
                SSTEP_G(b,c,d,a,b8v,0x455a14ed,20);
                SSTEP_G(a,b,c,d,_mm512_set1_epi32((int)block[13]),0xa9e3e905,5);
                SSTEP_G(d,a,b,c,_mm512_set1_epi32((int)block[2]),0xfcefa3f8,9);
                SSTEP_G(c,d,a,b,_mm512_set1_epi32((int)block[7]),0x676f02d9,14);
                SSTEP_G(b,c,d,a,b12v,0x8d2a4c8a,20);
                SSTEP_H(a,b,c,d,_mm512_set1_epi32((int)block[5]),0xfffa3942,4);
                SSTEP_H(d,a,b,c,b8v,0x8771f681,11);
                c=_mm512_add_epi32(c,_mm512_add_epi32(SH(d,a,b),_mm512_set1_epi32((int)(block[11]+0x6d9d6122u))));
                __mmask16 active=_mm512_testn_epi32_mask(c,bit15);
                if(!active) continue;
                c=_mm512_add_epi32(_mm512_rol_epi32(c,16),d);
                SSTEP_H(b,c,d,a,_mm512_set1_epi32((int)block[14]),0xfde5380c,23);
                SSTEP_H(a,b,c,d,_mm512_set1_epi32((int)block[1]),0xa4beea44,4);
                SSTEP_H(d,a,b,c,_mm512_set1_epi32((int)block[4]),0x4bdecfa9,11);
                SSTEP_H(c,d,a,b,_mm512_set1_epi32((int)block[7]),0xf6bb4b60,16);
                SSTEP_H(b,c,d,a,_mm512_set1_epi32((int)block[10]),0xbebfbc70,23);
                SSTEP_H(a,b,c,d,_mm512_set1_epi32((int)block[13]),0x289b7ec6,4);
                SSTEP_H(d,a,b,c,_mm512_set1_epi32((int)block[0]),0xeaa127fa,11);
                SSTEP_H(c,d,a,b,_mm512_set1_epi32((int)block[3]),0xd4ef3085,16);
                SSTEP_H(b,c,d,a,_mm512_set1_epi32((int)block[6]),0x04881d05,23);
                SSTEP_H(a,b,c,d,b9v,0xd9d4d039,4);
                SSTEP_H(d,a,b,c,b12v,0xe6db99e5,11);
                SSTEP_H(c,d,a,b,_mm512_set1_epi32((int)block[15]),0x1fa27cf8,16);
                SSTEP_H(b,c,d,a,_mm512_set1_epi32((int)block[2]),0xc4ac5665,23);
                active &= _mm512_testn_epi32_mask(_mm512_xor_si512(b,d),signbit);
                if(!active) continue;
                SSTEP_I(a,b,c,d,_mm512_set1_epi32((int)block[0]),0xf4292244,6);
                active &= _mm512_testn_epi32_mask(_mm512_xor_si512(a,c),signbit);
                if(!active) continue;
                SSTEP_I(d,a,b,c,_mm512_set1_epi32((int)block[7]),0x432aff97,10);
                active &= _mm512_test_epi32_mask(_mm512_xor_si512(b,d),signbit);
                if(!active) continue;
                SSTEP_I(c,d,a,b,_mm512_set1_epi32((int)block[14]),0xab9423a7,15);
                active &= _mm512_testn_epi32_mask(_mm512_xor_si512(a,c),signbit);
                if(!active) continue;
                SSTEP_I(b,c,d,a,_mm512_set1_epi32((int)block[5]),0xfc93a039,21);
                active &= _mm512_testn_epi32_mask(_mm512_xor_si512(b,d),signbit);
                if(!active) continue;
                _mm512_store_si512((void*)la,a); _mm512_store_si512((void*)lb,b);
                _mm512_store_si512((void*)lc,c); _mm512_store_si512((void*)ld,d);
                _mm512_store_si512((void*)l8,b8v); _mm512_store_si512((void*)l9,b9v); _mm512_store_si512((void*)l12,b12v);
                unsigned sm=(unsigned)active;
                while(sm){ unsigned lane=__builtin_ctz(sm); sm&=sm-1; block[8]=l8[lane]; block[9]=l9[lane]; block[12]=l12[lane]; if(finish_stevens_candidate(block,IV,la[lane],lb[lane],lc[lane],ld[lane])) return; }
            }
#undef SSTEP_I
#undef SSTEP_H
#undef SSTEP_G
#undef SI
#undef SH
#undef SG
#else
			for (unsigned k9 = 0; k9 < (1<<9); ++k9)
			{
				uint32 a = aa, b = bb, c = cc, d = dd;
				Q[Qoff + 9] = q9 ^ q9mask[k9];
				MD5_REVERSE_STEP(8, 0x698098d8, 7);
				MD5_REVERSE_STEP(9, 0x8b44f7af, 12);
				MD5_REVERSE_STEP(12, 0x6b901122, 7);

				MD5_STEP(GG, a, b, c, d, block[9], 0x21e1cde6, 5);
				MD5_STEP(GG, d, a, b, c, block[14], 0xc33707d6, 9);
				MD5_STEP(GG, c, d, a, b, block[3], 0xf4d50d87, 14);
				MD5_STEP(GG, b, c, d, a, block[8], 0x455a14ed, 20);
				MD5_STEP(GG, a, b, c, d, block[13], 0xa9e3e905, 5);
				MD5_STEP(GG, d, a, b, c, block[2], 0xfcefa3f8, 9);
				MD5_STEP(GG, c, d, a, b, block[7], 0x676f02d9, 14);
				MD5_STEP(GG, b, c, d, a, block[12], 0x8d2a4c8a, 20);
				MD5_STEP(HH, a, b, c, d, block[5], 0xfffa3942, 4);
				MD5_STEP(HH, d, a, b, c, block[8], 0x8771f681, 11);

				c += HH(d, a, b) + block[11] + 0x6d9d6122;
				if (0 != (c & (1 << 15)))
					continue;
				c = (c<<16 | c>>16) + d;
					
				MD5_STEP(HH, b, c, d, a, block[14], 0xfde5380c, 23);
				MD5_STEP(HH, a, b, c, d, block[1], 0xa4beea44, 4);
				MD5_STEP(HH, d, a, b, c, block[4], 0x4bdecfa9, 11);
				MD5_STEP(HH, c, d, a, b, block[7], 0xf6bb4b60, 16);
				MD5_STEP(HH, b, c, d, a, block[10], 0xbebfbc70, 23);
				MD5_STEP(HH, a, b, c, d, block[13], 0x289b7ec6, 4);
				MD5_STEP(HH, d, a, b, c, block[0], 0xeaa127fa, 11);
				MD5_STEP(HH, c, d, a, b, block[3], 0xd4ef3085, 16);
				MD5_STEP(HH, b, c, d, a, block[6], 0x04881d05, 23);
				MD5_STEP(HH, a, b, c, d, block[9], 0xd9d4d039, 4);
				MD5_STEP(HH, d, a, b, c, block[12], 0xe6db99e5, 11);
				MD5_STEP(HH, c, d, a, b, block[15], 0x1fa27cf8, 16);
				MD5_STEP(HH, b, c, d, a, block[2], 0xc4ac5665, 23);
				if (0 != ((b^d) & 0x80000000))
					continue;

				MD5_STEP(II, a, b, c, d, block[0], 0xf4292244, 6);
				if (0 != ((a^c) >> 31)) continue;
				MD5_STEP(II, d, a, b, c, block[7], 0x432aff97, 10);
				if (0 == ((b^d) >> 31)) continue;
				MD5_STEP(II, c, d, a, b, block[14], 0xab9423a7, 15);
				if (0 != ((a^c) >> 31)) continue;
				MD5_STEP(II, b, c, d, a, block[5], 0xfc93a039, 21);
				if (0 != ((b^d) >> 31)) continue;
				MD5_STEP(II, a, b, c, d, block[12], 0x655b59c3, 6);
				if (0 != ((a^c) >> 31)) continue;
				MD5_STEP(II, d, a, b, c, block[3], 0x8f0ccc92, 10);
				if (0 != ((b^d) >> 31)) continue;
				MD5_STEP(II, c, d, a, b, block[10], 0xffeff47d, 15);
				if (0 != ((a^c) >> 31)) continue;
				MD5_STEP(II, b, c, d, a, block[1], 0x85845dd1, 21);
				if (0 != ((b^d) >> 31)) continue;
				MD5_STEP(II, a, b, c, d, block[8], 0x6fa87e4f, 6);
				if (0 != ((a^c) >> 31)) continue;
				MD5_STEP(II, d, a, b, c, block[15], 0xfe2ce6e0, 10);
				if (0 != ((b^d) >> 31)) continue;
				MD5_STEP(II, c, d, a, b, block[6], 0xa3014314, 15);
				if (0 != ((a^c) >> 31)) continue;
				MD5_STEP(II, b, c, d, a, block[13], 0x4e0811a1, 21);
				if (0 == ((b^d) >> 31)) continue;
				MD5_STEP(II, a, b, c, d, block[4], 0xf7537e82, 6);
				if (0 != ((a^c) >> 31)) continue;
				MD5_STEP(II, d, a, b, c, block[11], 0xbd3af235, 10);
				if (0 != ((b^d) >> 31)) continue;
				MD5_STEP(II, c, d, a, b, block[2], 0x2ad7d2bb, 15);
				if (0 != ((a^c) >> 31)) continue;
				MD5_STEP(II, b, c, d, a, block[9], 0xeb86d391, 21);


				uint32 block2[16];
				uint32 IV1[4], IV2[4];
				for (int t = 0; t < 4; ++t)
				{
					IV1[t] = IV[t];
					IV2[t] = IV[t] + (1 << 31);
				}
				IV2[1] -= (1 << 25);
				IV2[2] -= (1 << 25);
				IV2[3] -= (1 << 25);

				for (int t = 0; t < 16; ++t)
					block2[t] = block[t];
				block2[4] += 1<<31;
				block2[11] += 1<<15;
				block2[14] += 1<<31;

				md5_compress(IV1, block);
				md5_compress(IV2, block2);
				if (IV2[0]==IV1[0] && IV2[1]==IV1[1] && IV2[2]==IV1[2] && IV2[3]==IV1[3])
					return;
				if (IV2[0] != IV1[0]) { }
			}
#endif

		}
	}
}
