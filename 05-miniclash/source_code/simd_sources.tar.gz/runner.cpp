#include <algorithm>
#include <cerrno>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <limits>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>

#include <fcntl.h>
#include <sched.h>
#include <signal.h>
#include <spawn.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

extern char **environ;

namespace {
struct Task {
    std::string in, out1, out2;
    bool done = false;
    unsigned running = 0;
    unsigned attempts = 0;
    unsigned failures = 0;
    std::chrono::steady_clock::time_point first_start{};
};

struct Attempt {
    std::size_t task = 0;
    std::string tmp1, tmp2;
    bool cancelled = false;
    std::chrono::steady_clock::time_point started{};
};

static inline std::uint64_t mix64(std::uint64_t x) {
    x += 0x9e3779b97f4a7c15ULL;
    x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
    x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL;
    return x ^ (x >> 31);
}

unsigned allowed_cpus() {
    cpu_set_t set;
    CPU_ZERO(&set);
    if (sched_getaffinity(0, sizeof(set), &set) == 0) {
        int n = CPU_COUNT(&set);
        if (n > 0) return static_cast<unsigned>(n);
    }
    long n = sysconf(_SC_NPROCESSORS_ONLN);
    return n > 0 ? static_cast<unsigned>(n) : 1U;
}

std::string dir_of(const std::string &p) {
    auto x = p.find_last_of('/');
    if (x == std::string::npos) return ".";
    return x == 0 ? "/" : p.substr(0, x);
}

void unlink_pair(const Attempt &a) {
    unlink(a.tmp1.c_str());
    unlink(a.tmp2.c_str());
}
}

int main(int argc, char **argv) {
    if (argc != 2) {
        std::cerr << "usage: " << argv[0] << " <tasks.txt>\n";
        return 2;
    }

    std::ifstream fin(argv[1]);
    if (!fin) {
        std::cerr << "cannot read " << argv[1] << "\n";
        return 1;
    }

    std::vector<Task> tasks;
    std::string line;
    while (std::getline(fin, line)) {
        std::istringstream is(line);
        Task t;
        std::string extra;
        if (!(is >> t.in)) continue;
        if (!(is >> t.out1 >> t.out2) || (is >> extra)) {
            std::cerr << "malformed task line\n";
            return 1;
        }
        tasks.push_back(std::move(t));
    }
    if (tasks.empty()) return 0;

    unsigned workers = std::min<unsigned>(32U, allowed_cpus());
    if (const char *e = std::getenv("MINICLASH_JOBS")) {
        char *end = nullptr;
        unsigned long v = std::strtoul(e, &end, 10);
        if (end != e && *end == '\0' && v) workers = std::min<unsigned>(workers, static_cast<unsigned>(v));
    }
    workers = std::max(1U, workers);

    const std::string bin = dir_of(argv[0]) + "/md5fastcoll";
    if (access(bin.c_str(), X_OK) != 0) {
        std::cerr << "missing executable " << bin << "\n";
        return 1;
    }

    timespec ts{};
    clock_gettime(CLOCK_MONOTONIC, &ts);
    const std::uint64_t nonce = (std::uint64_t(ts.tv_sec) << 32) ^ std::uint64_t(ts.tv_nsec) ^ std::uint64_t(getpid());

    std::unordered_map<pid_t, Attempt> procs;
    procs.reserve(workers * 4U);
    std::size_t next_original = 0, completed = 0;
    unsigned occupied = 0;
    bool fatal = false;

    auto spawn_one = [&](std::size_t ti) -> bool {
        Task &t = tasks[ti];
        const unsigned attempt = ++t.attempts;
        if (t.running == 0) t.first_start = std::chrono::steady_clock::now();

        const std::string suffix = ".mc." + std::to_string((long long)getpid()) + "." + std::to_string(ti) + "." + std::to_string(attempt);
        Attempt a{ti, t.out1 + suffix + ".1", t.out2 + suffix + ".2", false, std::chrono::steady_clock::now()};
        unlink_pair(a);

        std::uint64_t z1 = mix64(nonce ^ (std::uint64_t(ti) << 32) ^ attempt);
        std::uint64_t z2 = mix64(z1 ^ 0xd1b54a32d192ed03ULL);
        std::uint32_t seed1 = static_cast<std::uint32_t>(z1);
        std::uint32_t seed2 = static_cast<std::uint32_t>(z2);
        if ((seed1 | seed2) == 0) seed2 = 1;
        std::string s1 = std::to_string(seed1), s2 = std::to_string(seed2);

        std::vector<char*> av;
        av.reserve(13);
        auto push = [&](const std::string &x) { av.push_back(const_cast<char*>(x.c_str())); };
        push(bin);
        static std::string q = "-q", seed1opt = "--seed1", seed2opt = "--seed2", popt = "-p", oopt = "-o";
        push(q); push(seed1opt); push(s1); push(seed2opt); push(s2); push(popt); push(t.in); push(oopt); push(a.tmp1); push(a.tmp2);
        av.push_back(nullptr);

        posix_spawn_file_actions_t actions;
        posix_spawn_file_actions_init(&actions);
        posix_spawn_file_actions_addopen(&actions, STDOUT_FILENO, "/dev/null", O_WRONLY, 0);
        posix_spawn_file_actions_addopen(&actions, STDERR_FILENO, "/dev/null", O_WRONLY, 0);
        pid_t pid = -1;
        int rc = posix_spawn(&pid, bin.c_str(), &actions, nullptr, av.data(), environ);
        posix_spawn_file_actions_destroy(&actions);
        if (rc != 0) {
            std::cerr << "posix_spawn: " << std::strerror(rc) << "\n";
            unlink_pair(a);
            return false;
        }
        ++t.running;
        ++occupied;
        procs.emplace(pid, std::move(a));
        return true;
    };

    auto choose_hedge = [&]() -> std::size_t {
        std::size_t best = tasks.size();
        unsigned best_running = std::numeric_limits<unsigned>::max();
        auto best_age = std::chrono::steady_clock::duration::min();
        const auto now = std::chrono::steady_clock::now();
        for (std::size_t i = 0; i < tasks.size(); ++i) {
            const Task &t = tasks[i];
            if (t.done) continue;
            if (t.running == 0) return i;
            auto age = now - t.first_start;
            if (t.running < best_running || (t.running == best_running && age > best_age)) {
                best = i; best_running = t.running; best_age = age;
            }
        }
        return best;
    };

    auto fill = [&]() -> bool {
        while (occupied < workers && completed < tasks.size()) {
            std::size_t ti;
            if (next_original < tasks.size()) ti = next_original++;
            else {
                ti = choose_hedge();
                if (ti == tasks.size()) break;
            }
            if (!spawn_one(ti)) return false;
        }
        return true;
    };

    if (!fill()) fatal = true;

    while (!fatal && completed < tasks.size()) {
        // Kill only truly pathological random searches.  Normal tail handling
        // is done by speculative replicas once spare cores appear.
        #if defined(__AVX512F__)
        const double timeout_s = 8.0;
#else
        const double timeout_s = 30.0;
#endif

        const auto now = std::chrono::steady_clock::now();
        bool killed_timeout = false;
        for (auto &kv : procs) {
            Attempt &a = kv.second;
            if (a.cancelled) continue;
            const double age = std::chrono::duration<double>(now - a.started).count();
            if (age > timeout_s) {
                Task &t = tasks[a.task];
                a.cancelled = true;
                kill(kv.first, SIGKILL);
                if (t.running) --t.running;
                if (occupied) --occupied;
                killed_timeout = true;
            }
        }
        if (killed_timeout && !fill()) { fatal = true; break; }

        int status = 0;
        pid_t pid = waitpid(-1, &status, WNOHANG);
        if (pid == 0) {
            timespec nap{0, 1000000}; // 1 ms: negligible versus search time, no 20 ms Python polling penalty.
            nanosleep(&nap, nullptr);
            continue;
        }
        if (pid < 0) {
            if (errno == EINTR) continue;
            if (errno == ECHILD && completed == tasks.size()) break;
            std::cerr << "waitpid: " << std::strerror(errno) << "\n";
            fatal = true;
            break;
        }
        auto it = procs.find(pid);
        if (it == procs.end()) continue;
        Attempt a = std::move(it->second);
        procs.erase(it);
        Task &t = tasks[a.task];

        if (!a.cancelled) {
            if (t.running) --t.running;
            if (occupied) --occupied;
        }

        const bool ok = !a.cancelled && WIFEXITED(status) && WEXITSTATUS(status) == 0;
        if (ok && !t.done) {
            if (rename(a.tmp1.c_str(), t.out1.c_str()) != 0 || rename(a.tmp2.c_str(), t.out2.c_str()) != 0) {
                std::cerr << "rename failed: " << std::strerror(errno) << "\n";
                unlink_pair(a);
                fatal = true;
                break;
            }
            t.done = true;
            ++completed;

            // Cancel all losers immediately and free their scheduler slots before reap.
            for (auto &kv : procs) {
                Attempt &peer = kv.second;
                if (peer.task == a.task && !peer.cancelled) {
                    peer.cancelled = true;
                    kill(kv.first, SIGKILL);
                    if (t.running) --t.running;
                    if (occupied) --occupied;
                }
            }
        } else {
            unlink_pair(a);
            if (!a.cancelled && !t.done) {
                ++t.failures;
                if (t.failures > 4) {
                    std::cerr << "too many failures on " << t.in << "\n";
                    fatal = true;
                    break;
                }
            }
        }
        if (!fill()) fatal = true;
    }

    for (auto &kv : procs) kill(kv.first, SIGKILL);
    for (auto &kv : procs) unlink_pair(kv.second);
    while (waitpid(-1, nullptr, 0) > 0) {}
    return fatal ? 1 : (completed == tasks.size() ? 0 : 1);
}
